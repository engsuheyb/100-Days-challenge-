# Day 1 - 4 PCs, 1 Switch, 1 Router - Small Network Setup 🚀

## 🎯 Project Objectives
- Set static IP addresses on 4 PCs.
- Connect all 4 PCs to a single switch.
- Connect the switch to a router.
- Create two VLANs (VLAN 10 and VLAN 20) on the switch.
- Assign 2 PCs to VLAN 10 and 2 PCs to VLAN 20.
- Configure router-on-a-stick for inter-VLAN routing.
- Verify communication across VLANs.

---

## 🛠️ Devices Used
- 4 PCs (PC0, PC1, PC2, PC3)
- 1 Switch (Switch0)
- 1 Router (Router0)
- Straight-through Ethernet cables

---

## 📝 IP Address Plan

| Device | IP Address | Subnet Mask | VLAN |
|:------|:------------|:------------|:----|
| PC0 | 192.168.10.3 | 255.255.255.0 | VLAN 10 |
| PC1 | 192.168.10.4 | 255.255.255.0 | VLAN 10 |
| PC2 | 192.168.20.3 | 255.255.255.0 | VLAN 20 |
| PC3 | 192.168.20.4 | 255.255.255.0 | VLAN 20 |
| Router0 (VLAN10 subinterface) | 192.168.10.1 | 255.255.255.0 |  |
| Router0 (VLAN20 subinterface) | 192.168.20.1 | 255.255.255.0 |  |

---

## 🔧 Configuration Steps

### PCs
- Manually assign static IP addresses.

### Switch0
- Create VLAN 10 and VLAN 20.
- Assign appropriate ports to each VLAN.
- Configure trunk port to Router0.

### Router0
- Create subinterfaces for each VLAN.
- Assign IP addresses to subinterfaces.
- Enable encapsulation (dot1q) on trunk link.

---

## 🖥️ Topology Diagram
 [PC0]   [PC1]   [PC2]   [PC3]
    |       |       |       |
    +-------+-------+-------+
               |
            [Switch0]
               |
          [Router0]

---

## ✅ Results
- Successful pings between PCs in the same VLAN.
- Successful pings between PCs in different VLANs through the router.

---

## 🛠️ Files
- `project.pkt` — Packet Tracer simulation file
- `switch_config.txt` —Switch(config)#vlan 10 
Switch(config-vlan)#name Network1Vlan 
Switch(config-vlan)#int ran f0/1-2
Switch(config-if-range)#switchport access vlan 10
Switch(config-if-range)#end
Switch(config)#vlan 20
Switch(config-vlan)#name Network2Vlan
Switch(config-vlan)#int ran f0/3-4
Switch(config-if-range)#sw acc vlan 20
Switch(config)#end
Switch#show vla

VLAN Name                             Status    Ports
---- -------------------------------- --------- -------------------------------
1    default                          active    Fa0/5, Fa0/6, Fa0/7, Fa0/8
                                                Fa0/9, Fa0/10, Fa0/11, Fa0/12
                                                Fa0/13, Fa0/14, Fa0/15, Fa0/16
                                                Fa0/17, Fa0/18, Fa0/19, Fa0/20
                                                Fa0/21, Fa0/22, Fa0/23, Fa0/24
                                                Gig0/1, Gig0/2
10   Network1Vlan                     active    Fa0/1, Fa0/2
20   Network2Vlan                     active    Fa0/3, Fa0/4
1002 fddi-default                     active    
1003 token-ring-default               active    
1004 fddinet-default                  active    
1005 trnet-default                    active    

VLAN Type  SAID       MTU   Parent RingNo BridgeNo Stp  BrdgMode Trans1 Trans2
---- ----- ---------- ----- ------ ------ -------- ---- -------- ------ ------
1    enet  100001     1500  -      -      -        -    -        0      0
10   enet  100010     1500  -      -      -        -    -        0      0
20   enet  100020     1500  -      -      -        -    -        0      0
1002 fddi  101002     1500  -      -      -        -    -        0      0   
1003 tr    101003     1500  -      -      -        -    -        0      0   
1004 fdnet 101004     1500  -      -      -        ieee -        0      0   
1005 trnet 101005     1500  -      -      -        ibm  -        0      0   

VLAN Type  SAID       MTU   Parent RingNo BridgeNo Stp  BrdgMode Trans1 Trans2
---- ----- ---------- ----- ------ ------ -------- ---- -------- ------ ------

Remote SPAN VLANs
------------------------------------------------------------------------------

Primary Secondary Type              Ports
------- --------- ----------------- ------------------------------------------
Switch(config)#interface fastEthernet 0/5
Switch(config-if)#switchport mode trunk 

- `router_config.txt` —
Router>enable 
Router#conf t
Router(config)#interface gigabitEthernet 0/0
Router(config-if)#no shutdown 
Router(config-if)#end
Router#conf t
Router(config)#interface gigabitEthernet 0/0.10
Router(config-subif)#encapsulation dot1Q 10
Router(config-subif)#ip address 192.168.10.1 255.255.255.0
Router(config-subif)#end
Router#conf t
Router(config)#interface gigabitEthernet 0/0.20
Router(config-subif)#encapsulation dot1Q 20
Router(config-subif)#ip address 192.168.20.1 255.255.255.0
Router(config-subif)#end

---

# 🚀 Challenge Progress
-Day 1 Completed 🎯

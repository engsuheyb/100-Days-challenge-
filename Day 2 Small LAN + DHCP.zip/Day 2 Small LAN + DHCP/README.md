# Day 2 - 4 PCs, 1 Switch, 1 Router - DHCP Network Setup 🚀

## 🎯 Project Objectives
- Set up a router as a DHCP server.
- Connect all 4 PCs to a single switch.
- Connect the switch to the router.
- Automatically assign IP addresses to PCs via DHCP.
- Verify IP address assignment and network communication.

---

## 🛠️ Devices Used
- 4 PCs (PC0, PC1, PC2, PC3)
- 1 Switch (Switch0)
- 1 Router (Router0)
- Straight-through Ethernet cables

---

## 📝 IP Address Plan

| Device | IP Address | Subnet Mask | DHCP / Static |
|:------|:------------|:------------|:-------------|
| Router0 (Interface to LAN) | 192.168.1.1 | 255.255.255.0 | Static |
| PC0 | Assigned by DHCP | 255.255.255.0 | DHCP |
| PC1 | Assigned by DHCP | 255.255.255.0 | DHCP |
| PC2 | Assigned by DHCP | 255.255.255.0 | DHCP |
| PC3 | Assigned by DHCP | 255.255.255.0 | DHCP |
| PC4 | Assigned by DHCP | 255.255.255.0 | DHCP |
| PC5 | Assigned by DHCP | 255.255.255.0 | DHCP |

---

## 🔧 Configuration Steps

### PCs
- Set to "DHCP" mode for IP assignment.

### Switch0
- No special configuration needed (optional: set up VLAN 1 if organized).
- Connect PCs and Router via Switch.

### Router0
- Configure the router's LAN interface with a static IP.
- Set up a DHCP pool:
  - Network: 192.168.1.0/24
  - Default Gateway: 192.168.1.1
  - DNS Server: 8.8.8.8 (Google DNS)
- Exclude important static addresses (e.g., Router address).

---

## 🖥️ Topology Diagram

```
 [PC0]   [PC1]   [PC2]   [PC3]
    |       |       |       |
    +-------+-------+-------+
               |
            [Switch0]
               |
            [Router0]
```

---

## ✅ Results
- All PCs receive an IP address from the router dynamically.
- Successful pings between PCs and router.
- Successful Internet simulation (if DNS is configured).

---

## 🛠️ Files
- `Day 2 DHCP.pkt` — Packet Tracer simulation file
- `router_config.txt` — Router DHCP and interface config
- `switch_config.txt` — Basic switch config (optional)

---

# 🚀 Challenge Progress
- Day 2 Completed 🎯
